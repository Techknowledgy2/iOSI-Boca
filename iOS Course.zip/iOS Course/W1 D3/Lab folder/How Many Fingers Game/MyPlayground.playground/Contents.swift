//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// Divide you name by your zipcode - Team Member 1

